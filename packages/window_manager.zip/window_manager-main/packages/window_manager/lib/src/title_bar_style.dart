enum TitleBarStyle {
  normal,
  hidden,
}
